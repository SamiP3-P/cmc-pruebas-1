# AULA YA — Banco de preguntas

## Contenido
- Grados: 1.º, 2.º, 3.º, 4.º, 5.º, 8.º, 9.º y 10.º.
- Áreas: Español, Matemáticas, Sociales, Ciencias Naturales e Inglés.
- Temas incluidos: 987.
- Preguntas incluidas: 2961 (3 por tema).
- Formato: JSON UTF-8.

## Estructura
Cada archivo está organizado como:
`grado → materia → topics[] → topic → questions[]`

Cada pregunta contiene:
- `id`
- `question`
- `options` A/B/C/D
- `correct_answer`
- `explanation`
- `difficulty`
- `question_type`
- `competency`

## Uso en AULA YA
`index.json` permite localizar el archivo correspondiente a un grado y materia. `schema.json` define la estructura esperada para validación.

## Importante
Este es un **banco semilla generado automáticamente** a partir de la lista de temas suministrada para el proyecto. Las preguntas están pensadas como base de datos inicial para el SLM y deben ser revisadas por docentes antes de emplearse como evaluación oficial o material curricular definitivo.
